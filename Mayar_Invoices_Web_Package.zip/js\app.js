/**
 * Main Application Logic
 * Manages UI, Invoice Generation, Real-time calculations, CRUD, and Printing
 */

document.addEventListener('DOMContentLoaded', () => {
  DB.init();
  App.init();
});

const App = {
  currentInvoice: null,
  activeTab: 'invoices-tab',

  init: function() {
    this.bindEvents();
    this.renderProductsList();
    this.renderCustomersList();
    this.renderInvoicesList();
    this.loadSettingsForm();
    this.initNewInvoice();

    // Register service worker if available
    if ('serviceWorker' in navigator) {
      navigator.serviceWorker.register('sw.js').catch(err => console.log('SW registration note:', err));
    }
  },

  bindEvents: function() {
    // Navigation Tabs
    document.querySelectorAll('.nav-tab').forEach(tab => {
      tab.addEventListener('click', (e) => {
        const target = tab.dataset.tab;
        this.switchTab(target);
      });
    });

    // Logo Upload
    const logoInput = document.getElementById('setting-logo-file');
    if (logoInput) {
      logoInput.addEventListener('change', (e) => {
        const file = e.target.files[0];
        if (file) {
          const reader = new FileReader();
          reader.onload = (ev) => {
            const preview = document.getElementById('setting-logo-preview');
            if (preview) preview.src = ev.target.result;
            document.getElementById('setting-logo-url').value = ev.target.result;
          };
          reader.readAsDataURL(file);
        }
      });
    }

    // Invoice Date Hijri sync
    const invDateInput = document.getElementById('inv-date');
    if (invDateInput) {
      invDateInput.addEventListener('change', () => {
        this.syncHijriDate();
      });
    }

    // Global print trigger
    window.addEventListener('afterprint', () => {
      // Clean up if needed
    });
  },

  switchTab: function(tabId) {
    this.activeTab = tabId;
    document.querySelectorAll('.nav-tab').forEach(t => {
      t.classList.toggle('active', t.dataset.tab === tabId);
    });
    document.querySelectorAll('.tab-pane').forEach(p => {
      p.classList.toggle('active', p.id === tabId);
    });

    if (tabId === 'invoices-tab') this.renderInvoicesList();
    if (tabId === 'products-tab') this.renderProductsList();
    if (tabId === 'customers-tab') this.renderCustomersList();
    if (tabId === 'settings-tab') this.loadSettingsForm();
  },

  // -------------------------------------------------------------------------
  // INVOICE BUILDER & CALCULATIONS
  // -------------------------------------------------------------------------
  initNewInvoice: function(existingInvoice = null) {
    const settings = DB.getSettings();
    const today = new Date();
    const dateStr = today.toISOString().split('T')[0];
    const timeStr = today.toTimeString().split(' ')[0];

    if (existingInvoice) {
      this.currentInvoice = JSON.parse(JSON.stringify(existingInvoice));
    } else {
      const nextNum = String(settings.nextQuotationNumber || 1).padStart(6, '0');
      this.currentInvoice = {
        id: null,
        type: 'quotation',
        typeNameAr: 'عرض سعر مبيعات',
        typeNameEn: 'Sales Quotation',
        number: nextNum,
        date: dateStr,
        hijriDate: HijriConverter.toHijri(dateStr, -1),
        time: timeStr,
        orderNo: '',
        refNo: '',
        currency: settings.currency || 'SR ريال',
        exchangeRate: 1,
        costCenter: settings.costCenter || 'م.تكلفة 1 - 001',
        salesRep: settings.salesRep || '10-المدير',
        warehouse: settings.warehouse || 'مستودع 1 - 01',
        pageInfo: '1 من 1',
        customer: {
          id: '',
          name: '',
          taxNumber: 'لايوجد',
          crNumber: '',
          address: '',
          destination: 'محلي',
          representative: '',
          balance: '',
          competitors: ''
        },
        items: [
          {
            sr: 1,
            code: '96',
            description: 'كلوركس وسط ابو 1* 18*950مل',
            unit: 'كرتون',
            quantity: 50.00,
            price: 84.00,
            net: 4200.00,
            vatRate: 15,
            vatAmount: 630.00,
            totalWithVat: 4830.00
          }
        ],
        totalQuantity: 50.00,
        subtotal: 4200.00,
        additions: 0.00,
        grossTotal: 4200.00,
        discountPercent: 0,
        discountAmount: 0.00,
        netTotal: 4200.00,
        vatTotal: 630.00,
        grandTotal: 4830.00,
        tafqeet: '',
        paidAmount: 0.00,
        remainingAmount: 4830.00,
        user: settings.salesRep || '10-المدير',
        versionNo: 0,
        notes: '',
        status: 'unpaid'
      };
    }

    this.renderInvoiceForm();
    this.recalculateInvoice();
  },

  renderInvoiceForm: function() {
    const inv = this.currentInvoice;
    document.getElementById('inv-type').value = inv.type;
    document.getElementById('inv-number').value = inv.number;
    document.getElementById('inv-date').value = inv.date;
    document.getElementById('inv-hijri-date').value = inv.hijriDate || '';
    document.getElementById('inv-time').value = inv.time;
    document.getElementById('inv-order-no').value = inv.orderNo || '';
    document.getElementById('inv-ref-no').value = inv.refNo || '';
    document.getElementById('inv-cost-center').value = inv.costCenter || '';
    document.getElementById('inv-sales-rep').value = inv.salesRep || '';
    document.getElementById('inv-warehouse').value = inv.warehouse || '';

    // Customer Select dropdown
    this.populateCustomerSelect(inv.customer ? inv.customer.id : '');

    // Populate Customer Fields
    document.getElementById('inv-cust-name').value = inv.customer ? inv.customer.name : '';
    document.getElementById('inv-cust-tax').value = inv.customer ? inv.customer.taxNumber : 'لايوجد';
    document.getElementById('inv-cust-cr').value = inv.customer ? (inv.customer.crNumber || '') : '';
    document.getElementById('inv-cust-address').value = inv.customer ? (inv.customer.address || '') : '';
    document.getElementById('inv-cust-dest').value = inv.customer ? (inv.customer.destination || 'محلي') : 'محلي';
    document.getElementById('inv-cust-rep').value = inv.customer ? (inv.customer.representative || '') : '';
    document.getElementById('inv-cust-balance').value = inv.customer ? (inv.customer.balance || '') : '';

    // Summary fields
    document.getElementById('inv-additions').value = inv.additions || 0;
    document.getElementById('inv-discount-percent').value = inv.discountPercent || 0;
    document.getElementById('inv-discount-amount').value = inv.discountAmount || 0;
    document.getElementById('inv-paid').value = inv.paidAmount || 0;
    document.getElementById('inv-notes').value = inv.notes || '';

    this.renderInvoiceItemsRows();
  },

  populateCustomerSelect: function(selectedId = '') {
    const select = document.getElementById('inv-customer-picker');
    if (!select) return;
    const customers = DB.getCustomers();
    select.innerHTML = '<option value="">-- اختر عميل مسجل أو أدخل بيانات جديدة --</option>';
    customers.forEach(c => {
      const opt = document.createElement('option');
      opt.value = c.id;
      opt.textContent = `${c.name} ${c.taxNumber ? '(' + c.taxNumber + ')' : ''}`;
      if (c.id === selectedId) opt.selected = true;
      select.appendChild(opt);
    });
  },

  onCustomerSelectChange: function(customerId) {
    if (!customerId) return;
    const cust = DB.getCustomers().find(c => c.id === customerId);
    if (cust) {
      this.currentInvoice.customer = {
        id: cust.id,
        name: cust.name,
        taxNumber: cust.taxNumber || 'لايوجد',
        crNumber: cust.crNumber || '',
        address: cust.address || '',
        destination: cust.destination || 'محلي',
        representative: cust.representative || '',
        balance: cust.balance || ''
      };
      document.getElementById('inv-cust-name').value = cust.name;
      document.getElementById('inv-cust-tax').value = cust.taxNumber || 'لايوجد';
      document.getElementById('inv-cust-cr').value = cust.crNumber || '';
      document.getElementById('inv-cust-address').value = cust.address || '';
      document.getElementById('inv-cust-dest').value = cust.destination || 'محلي';
      document.getElementById('inv-cust-rep').value = cust.representative || '';
      document.getElementById('inv-cust-balance').value = cust.balance || '';
    }
  },

  renderInvoiceItemsRows: function() {
    const tbody = document.getElementById('inv-items-body');
    if (!tbody) return;
    tbody.innerHTML = '';

    const products = DB.getProducts();

    this.currentInvoice.items.forEach((item, index) => {
      const tr = document.createElement('tr');
      tr.innerHTML = `
        <td style="width: 40px; text-align: center; font-weight: bold;">${index + 1}</td>
        <td style="width: 100px;">
          <input type="text" class="form-control form-control-sm item-code-input" data-index="${index}" value="${item.code || ''}" placeholder="رقم الصنف">
        </td>
        <td>
          <div style="display: flex; gap: 4px;">
            <input type="text" class="form-control form-control-sm item-desc-input" data-index="${index}" value="${item.description || ''}" placeholder="اسم الصنف / البيان" style="flex: 1;">
            <select class="form-control form-control-sm item-picker-select" data-index="${index}" style="width: 130px;">
              <option value="">-- اختر صنف --</option>
              ${products.map(p => `<option value="${p.id}" ${p.code === item.code ? 'selected' : ''}>${p.name}</option>`).join('')}
            </select>
          </div>
        </td>
        <td style="width: 90px;">
          <input type="text" class="form-control form-control-sm item-unit-input" data-index="${index}" value="${item.unit || 'كرتون'}" placeholder="الوحدة">
        </td>
        <td style="width: 90px;">
          <input type="number" step="any" min="0" class="form-control form-control-sm item-qty-input" data-index="${index}" value="${item.quantity}" style="text-align: center;">
        </td>
        <td style="width: 100px;">
          <input type="number" step="0.01" min="0" class="form-control form-control-sm item-price-input" data-index="${index}" value="${item.price}" style="text-align: center;">
        </td>
        <td style="width: 100px; text-align: center; font-weight: bold; color: #002060;">
          ${(item.net || 0).toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
        </td>
        <td style="width: 80px;">
          <select class="form-control form-control-sm item-vat-select" data-index="${index}" style="text-align: center;">
            <option value="15" ${item.vatRate == 15 ? 'selected' : ''}>15%</option>
            <option value="5" ${item.vatRate == 5 ? 'selected' : ''}>5%</option>
            <option value="0" ${item.vatRate == 0 ? 'selected' : ''}>0%</option>
          </select>
        </td>
        <td style="width: 90px; text-align: center; color: #b91c1c; font-weight: 600;">
          ${(item.vatAmount || 0).toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
        </td>
        <td style="width: 110px; text-align: center; font-weight: bold; background-color: #f8fafc;">
          ${(item.totalWithVat || 0).toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
        </td>
        <td style="width: 50px; text-align: center;">
          <button type="button" class="btn btn-sm btn-outline btn-danger-icon" onclick="App.removeItemRow(${index})" title="حذف السطر">
            ✕
          </button>
        </td>
      `;
      tbody.appendChild(tr);
    });

    this.bindItemInputsEvents();
  },

  bindItemInputsEvents: function() {
    // Code input
    document.querySelectorAll('.item-code-input').forEach(input => {
      input.addEventListener('input', (e) => {
        const idx = parseInt(e.target.dataset.index);
        this.currentInvoice.items[idx].code = e.target.value;
      });
    });

    // Description input
    document.querySelectorAll('.item-desc-input').forEach(input => {
      input.addEventListener('input', (e) => {
        const idx = parseInt(e.target.dataset.index);
        this.currentInvoice.items[idx].description = e.target.value;
      });
    });

    // Unit input
    document.querySelectorAll('.item-unit-input').forEach(input => {
      input.addEventListener('input', (e) => {
        const idx = parseInt(e.target.dataset.index);
        this.currentInvoice.items[idx].unit = e.target.value;
      });
    });

    // Quantity input
    document.querySelectorAll('.item-qty-input').forEach(input => {
      input.addEventListener('input', (e) => {
        const idx = parseInt(e.target.dataset.index);
        this.currentInvoice.items[idx].quantity = parseFloat(e.target.value) || 0;
        this.recalculateInvoice();
      });
    });

    // Price input
    document.querySelectorAll('.item-price-input').forEach(input => {
      input.addEventListener('input', (e) => {
        const idx = parseInt(e.target.dataset.index);
        this.currentInvoice.items[idx].price = parseFloat(e.target.value) || 0;
        this.recalculateInvoice();
      });
    });

    // VAT Select
    document.querySelectorAll('.item-vat-select').forEach(select => {
      select.addEventListener('change', (e) => {
        const idx = parseInt(e.target.dataset.index);
        this.currentInvoice.items[idx].vatRate = parseFloat(e.target.value) || 0;
        this.recalculateInvoice();
      });
    });

    // Product Picker
    document.querySelectorAll('.item-picker-select').forEach(select => {
      select.addEventListener('change', (e) => {
        const idx = parseInt(e.target.dataset.index);
        const prodId = e.target.value;
        if (prodId) {
          const prod = DB.getProducts().find(p => p.id === prodId);
          if (prod) {
            this.currentInvoice.items[idx].code = prod.code;
            this.currentInvoice.items[idx].description = prod.name;
            this.currentInvoice.items[idx].unit = prod.unit || 'كرتون';
            this.currentInvoice.items[idx].price = prod.price || 0;
            this.currentInvoice.items[idx].vatRate = prod.vatRate || 15;
            this.renderInvoiceItemsRows();
            this.recalculateInvoice();
          }
        }
      });
    });
  },

  addItemRow: function() {
    this.currentInvoice.items.push({
      sr: this.currentInvoice.items.length + 1,
      code: '',
      description: '',
      unit: 'كرتون',
      quantity: 1,
      price: 0,
      net: 0,
      vatRate: 15,
      vatAmount: 0,
      totalWithVat: 0
    });
    this.renderInvoiceItemsRows();
    this.recalculateInvoice();
  },

  removeItemRow: function(index) {
    if (this.currentInvoice.items.length <= 1) {
      alert('يجب أن تحتوي الفاتورة على سطر واحد على الأقل.');
      return;
    }
    this.currentInvoice.items.splice(index, 1);
    this.renderInvoiceItemsRows();
    this.recalculateInvoice();
  },

  recalculateInvoice: function() {
    let totalQty = 0;
    let subtotal = 0;
    let totalVat = 0;

    this.currentInvoice.items.forEach((item, idx) => {
      item.sr = idx + 1;
      const qty = parseFloat(item.quantity) || 0;
      const price = parseFloat(item.price) || 0;
      const vatRate = parseFloat(item.vatRate) || 0;

      const net = qty * price;
      const vatAmount = net * (vatRate / 100);
      const totalWithVat = net + vatAmount;

      item.net = net;
      item.vatAmount = vatAmount;
      item.totalWithVat = totalWithVat;

      totalQty += qty;
      subtotal += net;
      totalVat += vatAmount;
    });

    const additions = parseFloat(document.getElementById('inv-additions')?.value) || 0;
    let discountPercent = parseFloat(document.getElementById('inv-discount-percent')?.value) || 0;
    let discountAmount = parseFloat(document.getElementById('inv-discount-amount')?.value) || 0;

    const grossTotal = subtotal + additions;

    if (discountPercent > 0 && discountAmount === 0) {
      discountAmount = grossTotal * (discountPercent / 100);
    }

    const netTotal = grossTotal - discountAmount;
    const grandTotal = netTotal + totalVat;
    const paidAmount = parseFloat(document.getElementById('inv-paid')?.value) || 0;
    const remainingAmount = grandTotal - paidAmount;

    this.currentInvoice.totalQuantity = totalQty;
    this.currentInvoice.subtotal = subtotal;
    this.currentInvoice.additions = additions;
    this.currentInvoice.grossTotal = grossTotal;
    this.currentInvoice.discountPercent = discountPercent;
    this.currentInvoice.discountAmount = discountAmount;
    this.currentInvoice.netTotal = netTotal;
    this.currentInvoice.vatTotal = totalVat;
    this.currentInvoice.grandTotal = grandTotal;
    this.currentInvoice.paidAmount = paidAmount;
    this.currentInvoice.remainingAmount = remainingAmount;

    // Currency Tafqeet
    const tafqeetText = Tafqeet.toArabicWords(grandTotal, 'ريال', 'هللة');
    this.currentInvoice.tafqeet = tafqeetText;

    // Update UI summary indicators
    const setVal = (id, val, isCurrency = true) => {
      const el = document.getElementById(id);
      if (el) {
        el.textContent = isCurrency 
          ? val.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })
          : val.toLocaleString('en-US');
      }
    };

    setVal('summary-subtotal', subtotal);
    setVal('summary-additions', additions);
    setVal('summary-gross', grossTotal);
    setVal('summary-discount', discountAmount);
    setVal('summary-net', netTotal);
    setVal('summary-vat', totalVat);
    setVal('summary-grand', grandTotal);
    setVal('summary-qty', totalQty, false);
    setVal('summary-paid', paidAmount);
    setVal('summary-remaining', remainingAmount);

    const tafqeetEl = document.getElementById('summary-tafqeet');
    if (tafqeetEl) tafqeetEl.textContent = tafqeetText;
  },

  syncHijriDate: function() {
    const gDate = document.getElementById('inv-date').value;
    if (gDate) {
      const hijri = HijriConverter.toHijri(gDate, -1);
      document.getElementById('inv-hijri-date').value = hijri;
    }
  },

  saveCurrentInvoice: function(andPrint = false) {
    // Read form headers into state
    const inv = this.currentInvoice;
    inv.type = document.getElementById('inv-type').value;
    inv.typeNameAr = inv.type === 'quotation' ? 'عرض سعر مبيعات' : 'فاتورة ضريبية';
    inv.typeNameEn = inv.type === 'quotation' ? 'Sales Quotation' : 'Tax Invoice';
    inv.number = document.getElementById('inv-number').value || '000001';
    inv.date = document.getElementById('inv-date').value;
    inv.hijriDate = document.getElementById('inv-hijri-date').value;
    inv.time = document.getElementById('inv-time').value || new Date().toTimeString().split(' ')[0];
    inv.orderNo = document.getElementById('inv-order-no').value;
    inv.refNo = document.getElementById('inv-ref-no').value;
    inv.costCenter = document.getElementById('inv-cost-center').value;
    inv.salesRep = document.getElementById('inv-sales-rep').value;
    inv.warehouse = document.getElementById('inv-warehouse').value;

    inv.customer = {
      id: document.getElementById('inv-customer-picker').value,
      name: document.getElementById('inv-cust-name').value || 'عميل نقدي',
      taxNumber: document.getElementById('inv-cust-tax').value || 'لايوجد',
      crNumber: document.getElementById('inv-cust-cr').value || '',
      address: document.getElementById('inv-cust-address').value || '',
      destination: document.getElementById('inv-cust-dest').value || 'محلي',
      representative: document.getElementById('inv-cust-rep').value || '',
      balance: document.getElementById('inv-cust-balance').value || ''
    };

    inv.notes = document.getElementById('inv-notes').value;

    this.recalculateInvoice();

    // Persist to DB
    const saved = DB.saveInvoice(inv);
    this.currentInvoice = saved;

    // Increment next invoice number in settings
    const settings = DB.getSettings();
    const currNumInt = parseInt(inv.number, 10);
    if (!isNaN(currNumInt)) {
      if (inv.type === 'quotation' && currNumInt >= (settings.nextQuotationNumber || 1)) {
        settings.nextQuotationNumber = currNumInt + 1;
      } else if (inv.type === 'tax_invoice' && currNumInt >= (settings.nextInvoiceNumber || 1)) {
        settings.nextInvoiceNumber = currNumInt + 1;
      }
      DB.saveSettings(settings);
    }

    alert('تم حفظ الفاتورة بنجاح!');
    this.renderInvoicesList();

    if (andPrint) {
      this.printInvoice(saved.id);
    }
  },

  // -------------------------------------------------------------------------
  // PRINT & VIEW 1:1 REPLICA OF سلنو.pdf
  // -------------------------------------------------------------------------
  printInvoice: function(invoiceId) {
    const inv = DB.getInvoiceById(invoiceId) || this.currentInvoice;
    if (!inv) return;

    this.renderPrintInvoiceTemplate(inv);

    // Open print preview modal or call window.print
    const modal = document.getElementById('modal-print-preview');
    if (modal) {
      modal.classList.add('show');
    }
  },

  closePrintModal: function() {
    const modal = document.getElementById('modal-print-preview');
    if (modal) modal.classList.remove('show');
  },

  executePrint: function() {
    window.print();
  },

  renderPrintInvoiceTemplate: function(inv) {
    const settings = DB.getSettings();
    const printEl = document.getElementById('invoice-print-wrapper');
    if (!printEl) return;

    // Format numbers
    const fmt = (num) => parseFloat(num || 0).toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
    const fmtQty = (num) => parseFloat(num || 0).toLocaleString('en-US');

    // Generate ZATCA QR Code
    let qrSvgHtml = '';
    if (settings.showZatcaQr) {
      const timestamp = `${inv.date}T${inv.time || '12:00:00'}Z`;
      const qrPayload = Zatca.generateQrPayload(
        settings.companyNameAr || settings.companyNameEn || 'Company',
        settings.taxNumber || '311193748100003',
        timestamp,
        inv.grandTotal,
        inv.vatTotal
      );
      if (qrPayload && typeof qrcode !== 'undefined') {
        const qr = qrcode(0, 'M');
        qr.addData(qrPayload);
        qr.make();
        qrSvgHtml = qr.createSvgTag(3, 0);
      }
    }

    // Logo image / SVG
    let logoHtml = '';
    if (settings.logoUrl) {
      logoHtml = `<img src="${settings.logoUrl}" alt="Logo" style="max-height: 65px; max-width: 140px;">`;
    } else {
      logoHtml = `<img src="assets/logo.svg" alt="Logo" style="max-height: 65px; max-width: 140px;">`;
    }

    // Build Table Rows matching exact سلنو.pdf
    const rowsHtml = inv.items.map(item => `
      <tr>
        <td style="width: 25px; text-align: center;">${item.sr}</td>
        <td style="width: 50px; text-align: center;">${item.code || ''}</td>
        <td class="desc">${item.description || ''}</td>
        <td style="width: 50px; text-align: center;">${item.unit || ''}</td>
        <td style="width: 50px; text-align: center;">${fmt(item.quantity)}</td>
        <td style="width: 55px; text-align: center;">${fmt(item.price)}</td>
        <td class="blue-net" style="width: 65px; text-align: center;">${fmt(item.net)}</td>
        <td style="width: 32px; text-align: center; font-size: 10px;">%${item.vatRate || 15}</td>
        <td style="width: 55px; text-align: center;">${fmt(item.vatAmount)}</td>
        <td style="width: 65px; text-align: center; font-weight: 700;">${fmt(item.totalWithVat)}</td>
      </tr>
    `).join('');

    printEl.innerHTML = `
      <!-- 1. Header Grid -->
      <div class="inv-header-grid">
        <div class="inv-company-en">
          ${settings.companyNameEn ? settings.companyNameEn.replace(' ', '<br>') : 'Mayar Jeddah<br>Trading Company'}
        </div>
        <div class="inv-company-logo">
          ${logoHtml}
        </div>
        <div class="inv-company-ar">
          ${settings.companyNameAr || 'شركة معيار جدة للتجارة<br>للمواد الغذائية'}
        </div>
      </div>

      <!-- Tax Numbers Row -->
      <div class="inv-tax-numbers-row">
        <div>Tax Number ${settings.taxNumber || '311193748100003'}</div>
        <div>الرقم الضريبي ${settings.taxNumber || '311193748100003'}</div>
      </div>

      <!-- Branch -->
      <div class="inv-branch-label">
        ${settings.branch || 'فرع 1 - 001'}
      </div>

      <!-- 2. Document Meta Box -->
      <div class="inv-meta-box">
        <!-- Left Sub-Box -->
        <div class="inv-meta-left">
          <div class="inv-meta-row"><span class="label">الصفحة:</span> <span>${inv.pageInfo || '1 من 1'}</span></div>
          <div class="inv-meta-row"><span class="label">م.التكلفة:</span> <span>${inv.costCenter || 'م.تكلفة 1 - 001'}</span></div>
          <div class="inv-meta-row"><span class="label">المندوب :</span> <span>${inv.salesRep || ''}</span></div>
          <div class="inv-meta-row"><span class="label">المستودع :</span> <span>${inv.warehouse || 'مستودع 1 - 01'}</span></div>
        </div>

        <!-- Center Sub-Box -->
        <div class="inv-meta-center">
          <div class="inv-doc-title">${inv.typeNameAr || 'عرض سعر مبيعات'}</div>
          <div class="inv-meta-center-details">
            <div class="inv-meta-row"><span class="label">الرقم :</span> <span style="font-weight: 800;">${inv.number}</span></div>
            <div class="inv-meta-row"><span class="label">النوع :</span> <span>${inv.type === 'quotation' ? 'عرض بيع' : 'فاتورة ضريبية'}</span></div>
            <div class="inv-meta-row"><span class="label">المرجع :</span> <span>${inv.refNo || ''}</span></div>
            <div class="inv-meta-row"><span class="label">الطلبية :</span> <span>${inv.orderNo || ''}</span></div>
            <div class="inv-meta-row"><span class="label">الصرف :</span> <span>${inv.exchangeRate || 1}</span></div>
            <div class="inv-meta-row"><span class="label">العملة :</span> <span>${inv.currency || 'SR ريال'}</span></div>
          </div>
        </div>

        <!-- Right Sub-Box -->
        <div class="inv-meta-right">
          <div class="inv-meta-row"><span class="label">التاريخ:</span> <span>${inv.date}</span></div>
          <div class="inv-meta-row"><span class="label">الموافق:</span> <span>${inv.hijriDate || ''}</span></div>
          <div class="inv-meta-row"><span class="label">الوقت:</span> <span>${inv.time || ''}</span></div>
        </div>
      </div>

      <!-- 3. Customer Information Strip -->
      <div class="inv-customer-strip">
        <div class="inv-cust-col">
          <div class="inv-cust-row"><span class="lbl">العميل</span> <span>${inv.customer ? inv.customer.name : ''}</span></div>
          <div class="inv-cust-row"><span class="lbl">العنــوان :</span> <span>${inv.customer ? (inv.customer.address || '') : ''}</span></div>
          <div class="inv-cust-row"><span class="lbl">الرصيد</span> <span>${inv.customer ? (inv.customer.balance || 'محلي') : 'محلي'}</span></div>
        </div>

        <div class="inv-cust-col">
          <div class="inv-cust-row"><span class="lbl">برقم ضريبي</span> <span>${inv.customer ? (inv.customer.taxNumber || 'لايوجد') : 'لايوجد'}</span></div>
          <div class="inv-cust-row" style="margin-top: 14px;"><span class="lbl">الوجهة</span> <span>${inv.customer ? (inv.customer.destination || 'محلي') : 'محلي'}</span></div>
        </div>

        <div class="inv-cust-col">
          <div class="inv-cust-row"><span class="lbl">ر.السجل</span> <span>${inv.customer ? (inv.customer.crNumber || '') : ''}</span></div>
          <div class="inv-cust-row" style="margin-top: 14px;"><span>${inv.customer ? (inv.customer.representative || 'ممثل العميل') : 'ممثل العميل'}</span></div>
        </div>

        <div class="inv-cust-col">
          <div class="inv-cust-row" style="margin-top: 18px;"><span>${inv.customer ? (inv.customer.competitors || 'المنافسين') : 'المنافسين'}</span></div>
        </div>
      </div>

      <!-- 4. Region Branding Banner -->
      <div class="inv-region-bar">
        <div class="inv-region-block b1"></div>
        <div class="inv-region-block b2">RegionBrn</div>
        <div class="inv-region-block b3"></div>
        <div class="inv-region-block b4"></div>
        <div class="inv-region-block b5"></div>
        <div class="inv-region-block b6"></div>
      </div>

      <!-- 5. Main Items Table -->
      <table class="inv-items-table">
        <thead>
          <tr>
            <th rowspan="2" style="width: 25px;">م</th>
            <th rowspan="2" style="width: 50px;">ر.الصنف</th>
            <th rowspan="2">البيــــان</th>
            <th rowspan="2" style="width: 50px;">الوحدة</th>
            <th rowspan="2" style="width: 50px;">الكمية</th>
            <th rowspan="2" style="width: 55px;">السعر</th>
            <th rowspan="2" style="width: 65px; color: #002060;">الصافي</th>
            <th colspan="2" style="width: 87px;">ضريبة قيمة مضافة</th>
            <th rowspan="2" style="width: 65px;">الصافي+الضريبة</th>
          </tr>
          <tr>
            <th style="width: 32px; font-size: 10px;">%</th>
            <th style="width: 55px; font-size: 10px;">القيمة</th>
          </tr>
        </thead>
        <tbody>
          ${rowsHtml}
        </tbody>
      </table>

      <!-- 6. Totals Grid -->
      <div class="inv-totals-grid">
        <!-- Left: Financial Box -->
        <div class="inv-fin-box">
          <div class="inv-fin-row bold-blue">
            <span>الاجمــالي</span>
            <span>${fmt(inv.subtotal)}</span>
          </div>
          <div class="inv-fin-row">
            <span>الاضـافــات</span>
            <span>${fmt(inv.additions)}</span>
          </div>
          <div class="inv-fin-row">
            <span>الاجمالي الكلي</span>
            <span>${fmt(inv.grossTotal)}</span>
          </div>
          <div class="inv-fin-row">
            <span>الخصـم</span>
            <span>${fmt(inv.discountAmount)} | %${inv.discountPercent || 0}</span>
          </div>
          <div class="inv-fin-row">
            <span>الصـافي</span>
            <span>${fmt(inv.netTotal)}</span>
          </div>
          <div class="inv-fin-row vat-header">
            <span>إجمالي ضريبة القيمة المضافة 15 %</span>
            <span>${fmt(inv.vatTotal)}</span>
          </div>
          <div class="inv-fin-row grand-total">
            <span>الصافي شامل ض.ق VAT</span>
            <span style="font-size: 13px; font-weight: 800;">${fmt(inv.grandTotal)}</span>
          </div>
        </div>

        <!-- Middle: Quantities & Payments -->
        <div class="inv-mid-boxes">
          <div class="inv-mid-card">
            <span>المدفوع</span>
            <span>${fmt(inv.paidAmount)}</span>
          </div>
          <div class="inv-mid-card" style="margin-top: 4px;">
            <span>المتبقي</span>
            <span style="font-weight: 800;">${fmt(inv.remainingAmount)}</span>
          </div>
          <div class="inv-mid-card" style="margin-top: 4px;">
            <span>إجمالي الكمية</span>
            <span>${fmtQty(inv.totalQuantity)}</span>
          </div>
        </div>

        <!-- Right: Metadata & Notes -->
        <div class="inv-right-meta">
          <div><span style="font-weight: 700;">المستخدم :</span> ${inv.user || '10-المدير'}</div>
          <div><span style="font-weight: 700;">رقم النسخة :</span> ${inv.versionNo || 0}</div>
          <div style="font-size: 10px; color: #444;">${inv.date} ${inv.time || ''}</div>
          <div style="margin-top: 4px; font-weight: 700;">ملاحظات :</div>
          <div style="font-size: 10px; color: #333; min-height: 25px;">${inv.notes || ''}</div>
        </div>
      </div>

      <!-- 7. Tafqeet Banner Box -->
      <div class="inv-tafqeet-box">
        ${inv.tafqeet || ''}
      </div>

      <!-- 8. Signatures Line -->
      <div class="inv-signatures">
        <div>المستلـــــم : .................................</div>
        <div>البــــــائــــــــــــع : .................................</div>
      </div>

      <!-- Optional ZATCA QR Code -->
      ${settings.showZatcaQr && qrSvgHtml ? `
        <div class="inv-qr-section" style="position: absolute; bottom: 8mm; left: 15mm; text-align: center;">
          <div style="width: 75px; height: 75px;">${qrSvgHtml}</div>
          <div style="font-size: 8px; color: #555; margin-top: 2px;">فاتورة إلكترونية معتمدة</div>
        </div>
      ` : ''}
    `;
  },

  // -------------------------------------------------------------------------
  // INVOICES LIST VIEW
  // -------------------------------------------------------------------------
  renderInvoicesList: function() {
    const listContainer = document.getElementById('invoices-table-body');
    if (!listContainer) return;
    const invoices = DB.getInvoices();

    if (invoices.length === 0) {
      listContainer.innerHTML = '<tr><td colspan="7" style="text-align:center; padding: 24px; color: #888;">لا توجد فواتير بعد. انقر على "إنشاء فاتورة جديدة" للبدء.</td></tr>';
      return;
    }

    listContainer.innerHTML = invoices.map(inv => `
      <tr>
        <td style="font-weight: bold;">${inv.number}</td>
        <td>
          <span class="badge ${inv.type === 'quotation' ? 'badge-info' : 'badge-primary'}" style="background: #e0f2fe; color: #0369a1; padding: 2px 8px; border-radius: 4px; font-size: 12px; font-weight: 600;">
            ${inv.typeNameAr || (inv.type === 'quotation' ? 'عرض سعر' : 'فاتورة')}
          </span>
        </td>
        <td>${inv.date}</td>
        <td style="font-weight: 600;">${inv.customer ? inv.customer.name : ''}</td>
        <td style="font-weight: bold; color: #002060;">${(inv.grandTotal || 0).toLocaleString('en-US', { minimumFractionDigits: 2 })} SR</td>
        <td>
          <span style="font-size: 12px; font-weight: 600; color: ${inv.remainingAmount <= 0 ? '#059669' : '#d97706'}">
            ${inv.remainingAmount <= 0 ? 'مدفوع بالكامل' : 'متبقي: ' + (inv.remainingAmount || 0).toLocaleString('en-US', { minimumFractionDigits: 2 })}
          </span>
        </td>
        <td>
          <div style="display: flex; gap: 6px; justify-content: flex-end;">
            <button class="btn btn-sm btn-primary" onclick="App.printInvoice('${inv.id}')" title="عرض وطباعة">
              🖨️ طباعة
            </button>
            <button class="btn btn-sm btn-outline" onclick="App.editInvoice('${inv.id}')" title="تعديل">
              ✏️
            </button>
            <button class="btn btn-sm btn-outline" onclick="App.duplicateInvoice('${inv.id}')" title="نسخ إلى جديد">
              📄
            </button>
            <button class="btn btn-sm btn-danger" onclick="App.deleteInvoice('${inv.id}')" title="حذف">
              🗑️
            </button>
          </div>
        </td>
      </tr>
    `).join('');
  },

  editInvoice: function(id) {
    const inv = DB.getInvoiceById(id);
    if (inv) {
      this.initNewInvoice(inv);
      this.switchTab('new-invoice-tab');
    }
  },

  duplicateInvoice: function(id) {
    const inv = DB.getInvoiceById(id);
    if (inv) {
      const copy = JSON.parse(JSON.stringify(inv));
      copy.id = null;
      const settings = DB.getSettings();
      copy.number = String(settings.nextQuotationNumber || 1).padStart(6, '0');
      copy.date = new Date().toISOString().split('T')[0];
      copy.time = new Date().toTimeString().split(' ')[0];
      copy.hijriDate = HijriConverter.toHijri(copy.date, -1);
      this.initNewInvoice(copy);
      this.switchTab('new-invoice-tab');
    }
  },

  deleteInvoice: function(id) {
    if (confirm('هل أنت متأكد من حذف هذه الفاتورة؟')) {
      DB.deleteInvoice(id);
      this.renderInvoicesList();
    }
  },

  // -------------------------------------------------------------------------
  // PRODUCTS & CATEGORIES
  // -------------------------------------------------------------------------
  renderProductsList: function() {
    const tbody = document.getElementById('products-table-body');
    if (!tbody) return;
    const products = DB.getProducts();

    if (products.length === 0) {
      tbody.innerHTML = '<tr><td colspan="7" style="text-align: center; padding: 20px; color: #888;">لا توجد منتجات مسجلة. أضف منتجك الأول الآن.</td></tr>';
      return;
    }

    tbody.innerHTML = products.map(p => `
      <tr>
        <td style="font-weight: bold; color: #0284c7;">${p.code || '-'}</td>
        <td style="font-weight: 600;">${p.name}</td>
        <td><span style="background: #f1f5f9; padding: 2px 6px; border-radius: 4px; font-size: 12px;">${p.category || 'عام'}</span></td>
        <td>${p.unit || 'كرتون'}</td>
        <td style="font-weight: bold;">${(p.price || 0).toLocaleString('en-US', { minimumFractionDigits: 2 })} ريال</td>
        <td>%${p.vatRate || 15}</td>
        <td>
          <div style="display: flex; gap: 6px; justify-content: flex-end;">
            <button class="btn btn-sm btn-outline" onclick="App.openEditProductModal('${p.id}')">تعديل</button>
            <button class="btn btn-sm btn-danger" onclick="App.deleteProduct('${p.id}')">حذف</button>
          </div>
        </td>
      </tr>
    `).join('');
  },

  openAddProductModal: function() {
    document.getElementById('modal-prod-title').textContent = 'إضافة منتج جديد';
    document.getElementById('prod-id').value = '';
    document.getElementById('prod-code').value = '';
    document.getElementById('prod-name').value = '';
    document.getElementById('prod-name-en').value = '';
    document.getElementById('prod-unit').value = 'كرتون';
    document.getElementById('prod-price').value = '';
    document.getElementById('prod-vat').value = '15';
    document.getElementById('prod-category').value = 'منظفات';
    document.getElementById('modal-product').classList.add('show');
  },

  openEditProductModal: function(id) {
    const prod = DB.getProducts().find(p => p.id === id);
    if (!prod) return;
    document.getElementById('modal-prod-title').textContent = 'تعديل منتج';
    document.getElementById('prod-id').value = prod.id;
    document.getElementById('prod-code').value = prod.code || '';
    document.getElementById('prod-name').value = prod.name;
    document.getElementById('prod-name-en').value = prod.nameEn || '';
    document.getElementById('prod-unit').value = prod.unit || 'كرتون';
    document.getElementById('prod-price').value = prod.price;
    document.getElementById('prod-vat').value = prod.vatRate || 15;
    document.getElementById('prod-category').value = prod.category || 'عام';
    document.getElementById('modal-product').classList.add('show');
  },

  closeProductModal: function() {
    document.getElementById('modal-product').classList.remove('show');
  },

  saveProductForm: function() {
    const name = document.getElementById('prod-name').value.trim();
    if (!name) {
      alert('يرجى كتابة اسم المنتج.');
      return;
    }

    const prod = {
      id: document.getElementById('prod-id').value || null,
      code: document.getElementById('prod-code').value.trim(),
      name: name,
      nameEn: document.getElementById('prod-name-en').value.trim(),
      unit: document.getElementById('prod-unit').value.trim() || 'كرتون',
      price: parseFloat(document.getElementById('prod-price').value) || 0,
      vatRate: parseFloat(document.getElementById('prod-vat').value) || 15,
      category: document.getElementById('prod-category').value.trim() || 'عام'
    };

    DB.saveProduct(prod);
    this.closeProductModal();
    this.renderProductsList();
  },

  deleteProduct: function(id) {
    if (confirm('هل أنت متأكد من حذف هذا المنتج؟')) {
      DB.deleteProduct(id);
      this.renderProductsList();
    }
  },

  // -------------------------------------------------------------------------
  // CUSTOMERS
  // -------------------------------------------------------------------------
  renderCustomersList: function() {
    const tbody = document.getElementById('customers-table-body');
    if (!tbody) return;
    const customers = DB.getCustomers();

    if (customers.length === 0) {
      tbody.innerHTML = '<tr><td colspan="6" style="text-align: center; padding: 20px; color: #888;">لا يوجد عملاء مسجلين. أضف عميلك الأول الآن.</td></tr>';
      return;
    }

    tbody.innerHTML = customers.map(c => `
      <tr>
        <td style="font-weight: bold;">${c.name}</td>
        <td>${c.taxNumber || 'لايوجد'}</td>
        <td>${c.crNumber || '-'}</td>
        <td>${c.phone || '-'}</td>
        <td>${c.address || '-'}</td>
        <td>
          <div style="display: flex; gap: 6px; justify-content: flex-end;">
            <button class="btn btn-sm btn-outline" onclick="App.openEditCustomerModal('${c.id}')">تعديل</button>
            <button class="btn btn-sm btn-danger" onclick="App.deleteCustomer('${c.id}')">حذف</button>
          </div>
        </td>
      </tr>
    `).join('');
  },

  openAddCustomerModal: function() {
    document.getElementById('modal-cust-title').textContent = 'إضافة عميل جديد';
    document.getElementById('cust-id').value = '';
    document.getElementById('cust-name').value = '';
    document.getElementById('cust-tax').value = 'لايوجد';
    document.getElementById('cust-cr').value = '';
    document.getElementById('cust-phone').value = '';
    document.getElementById('cust-address').value = '';
    document.getElementById('cust-dest').value = 'محلي';
    document.getElementById('modal-customer').classList.add('show');
  },

  openEditCustomerModal: function(id) {
    const cust = DB.getCustomers().find(c => c.id === id);
    if (!cust) return;
    document.getElementById('modal-cust-title').textContent = 'تعديل بيانات عميل';
    document.getElementById('cust-id').value = cust.id;
    document.getElementById('cust-name').value = cust.name;
    document.getElementById('cust-tax').value = cust.taxNumber || 'لايوجد';
    document.getElementById('cust-cr').value = cust.crNumber || '';
    document.getElementById('cust-phone').value = cust.phone || '';
    document.getElementById('cust-address').value = cust.address || '';
    document.getElementById('cust-dest').value = cust.destination || 'محلي';
    document.getElementById('modal-customer').classList.add('show');
  },

  closeCustomerModal: function() {
    document.getElementById('modal-customer').classList.remove('show');
  },

  saveCustomerForm: function() {
    const name = document.getElementById('cust-name').value.trim();
    if (!name) {
      alert('يرجى كتابة اسم العميل.');
      return;
    }

    const cust = {
      id: document.getElementById('cust-id').value || null,
      name: name,
      taxNumber: document.getElementById('cust-tax').value.trim() || 'لايوجد',
      crNumber: document.getElementById('cust-cr').value.trim(),
      phone: document.getElementById('cust-phone').value.trim(),
      address: document.getElementById('cust-address').value.trim(),
      destination: document.getElementById('cust-dest').value.trim() || 'محلي'
    };

    DB.saveCustomer(cust);
    this.closeCustomerModal();
    this.renderCustomersList();
    this.populateCustomerSelect();
  },

  deleteCustomer: function(id) {
    if (confirm('هل أنت متأكد من حذف هذا العميل؟')) {
      DB.deleteCustomer(id);
      this.renderCustomersList();
      this.populateCustomerSelect();
    }
  },

  // -------------------------------------------------------------------------
  // COMPANY SETTINGS
  // -------------------------------------------------------------------------
  loadSettingsForm: function() {
    const s = DB.getSettings();
    document.getElementById('setting-name-ar').value = s.companyNameAr || '';
    document.getElementById('setting-name-en').value = s.companyNameEn || '';
    document.getElementById('setting-tax').value = s.taxNumber || '';
    document.getElementById('setting-cr').value = s.crNumber || '';
    document.getElementById('setting-branch').value = s.branch || '';
    document.getElementById('setting-cost-center').value = s.costCenter || '';
    document.getElementById('setting-warehouse').value = s.warehouse || '';
    document.getElementById('setting-sales-rep').value = s.salesRep || '';
    document.getElementById('setting-currency').value = s.currency || 'SR ريال';
    document.getElementById('setting-vat').value = s.defaultVatRate || 15;
    document.getElementById('setting-next-quote').value = s.nextQuotationNumber || 64;
    document.getElementById('setting-next-inv').value = s.nextInvoiceNumber || 3458;
    document.getElementById('setting-show-qr').checked = s.showZatcaQr !== false;
    document.getElementById('setting-logo-url').value = s.logoUrl || '';

    const preview = document.getElementById('setting-logo-preview');
    if (preview) preview.src = s.logoUrl || 'assets/logo.svg';
  },

  saveSettingsForm: function() {
    const s = {
      companyNameAr: document.getElementById('setting-name-ar').value.trim(),
      companyNameEn: document.getElementById('setting-name-en').value.trim(),
      taxNumber: document.getElementById('setting-tax').value.trim(),
      crNumber: document.getElementById('setting-cr').value.trim(),
      branch: document.getElementById('setting-branch').value.trim(),
      costCenter: document.getElementById('setting-cost-center').value.trim(),
      warehouse: document.getElementById('setting-warehouse').value.trim(),
      salesRep: document.getElementById('setting-sales-rep').value.trim(),
      currency: document.getElementById('setting-currency').value.trim() || 'SR ريال',
      defaultVatRate: parseFloat(document.getElementById('setting-vat').value) || 15,
      nextQuotationNumber: parseInt(document.getElementById('setting-next-quote').value) || 1,
      nextInvoiceNumber: parseInt(document.getElementById('setting-next-inv').value) || 1,
      showZatcaQr: document.getElementById('setting-show-qr').checked,
      logoUrl: document.getElementById('setting-logo-url').value
    };

    DB.saveSettings(s);
    alert('تم حفظ الإعدادات بنجاح!');
  },

  // -------------------------------------------------------------------------
  // BACKUP & RESTORE
  // -------------------------------------------------------------------------
  downloadBackup: function() {
    const dataStr = DB.exportBackup();
    const blob = new Blob([dataStr], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `invoices_backup_${new Date().toISOString().split('T')[0]}.json`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  },

  restoreBackup: function(fileInput) {
    const file = fileInput.files[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (e) => {
      const ok = DB.importBackup(e.target.result);
      if (ok) {
        alert('تمت استعادة البيانات بنجاح!');
        location.reload();
      } else {
        alert('حدث خطأ أثناء قراءة ملف النسخة الاحتياطية. يرجى التأكد من صحة الملف.');
      }
    };
    reader.readAsText(file);
  }
};
